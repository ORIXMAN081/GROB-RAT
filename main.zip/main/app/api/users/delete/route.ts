import { type NextRequest, NextResponse } from "next/server"
import { deleteUser } from "@/lib/db-server"

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    deleteUser(userId)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[Delete User Error]", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
